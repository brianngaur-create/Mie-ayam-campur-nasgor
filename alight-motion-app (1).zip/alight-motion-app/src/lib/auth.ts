"use client";

export type Role = "admin" | "user";

const KEY = "am_role";

export function getRole(): Role | null {
  if (typeof window === "undefined") return null;
  const v = window.localStorage.getItem(KEY);
  return v === "admin" || v === "user" ? v : null;
}

export function setRole(role: Role) {
  window.localStorage.setItem(KEY, role);
}

export function clearRole() {
  window.localStorage.removeItem(KEY);
}

export function tryLogin(password: string): Role | null {
  const adminPass = process.env.NEXT_PUBLIC_ADMIN_PASSWORD || "admin123";
  const userPass = process.env.NEXT_PUBLIC_USER_PASSWORD || "user123";
  if (password === adminPass) return "admin";
  if (password === userPass) return "user";
  return null;
}
