"use client";

import { useRouter } from "next/navigation";
import { clearRole } from "@/lib/auth";

export default function Header({ role }: { role: "admin" | "user" }) {
  const router = useRouter();

  function handleLogout() {
    clearRole();
    router.replace("/");
  }

  return (
    <header className="border-b border-zinc-800 bg-zinc-950/70 backdrop-blur sticky top-0 z-10">
      <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 grid place-items-center text-sm font-bold">
            AM
          </div>
          <div>
            <div className="text-sm font-semibold leading-tight">Alight Motion Premium</div>
            <div className="text-xs text-zinc-400 leading-tight">
              {role === "admin" ? "Panel Admin" : "Panel User"}
            </div>
          </div>
        </div>
        <button
          onClick={handleLogout}
          className="text-sm bg-zinc-800 hover:bg-zinc-700 transition rounded-lg px-3 py-1.5"
        >
          Keluar
        </button>
      </div>
    </header>
  );
}
