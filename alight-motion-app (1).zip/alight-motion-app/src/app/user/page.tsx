"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { collection, onSnapshot, orderBy, query } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { getRole } from "@/lib/auth";
import Header from "@/components/Header";
import CopyButton from "@/components/CopyButton";

type Account = {
  id: string;
  label?: string;
  email: string;
  password?: string;
  tempEmailLink: string;
  note?: string;
};

export default function UserPage() {
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    const role = getRole();
    if (role !== "user" && role !== "admin") {
      router.replace("/");
      return;
    }
    setReady(true);
  }, [router]);

  useEffect(() => {
    if (!ready) return;
    try {
      const q = query(collection(db, "accounts"), orderBy("createdAt", "desc"));
      const unsub = onSnapshot(
        q,
        (snap) => {
          setAccounts(
            snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Account, "id">) })),
          );
        },
        (err) => setError(err.message),
      );
      return () => unsub();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }, [ready]);

  if (!ready) return null;

  const filtered = accounts.filter((a) => {
    const s = search.toLowerCase();
    return (
      !s ||
      a.email.toLowerCase().includes(s) ||
      (a.label || "").toLowerCase().includes(s)
    );
  });

  return (
    <div className="min-h-screen">
      <Header role="user" />

      <main className="max-w-5xl mx-auto px-4 py-6 space-y-6">
        <section className="bg-gradient-to-br from-violet-600/20 to-fuchsia-600/10 border border-violet-500/30 rounded-2xl p-5">
          <h1 className="text-xl font-semibold">Daftar Akun Premium</h1>
          <p className="text-sm text-zinc-300 mt-1">
            Salin email akun, lalu buka link email temp untuk menerima kode verifikasi.
          </p>
        </section>

        <div>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari email atau label..."
            className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 outline-none focus:border-violet-500"
          />
        </div>

        {error && (
          <div className="text-sm text-red-400 bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2">
            {error}
          </div>
        )}

        {filtered.length === 0 ? (
          <div className="bg-zinc-900/40 border border-dashed border-zinc-800 rounded-2xl p-8 text-center text-zinc-400">
            Belum ada akun tersedia.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filtered.map((acc) => (
              <article
                key={acc.id}
                className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 flex flex-col gap-3"
              >
                <div>
                  <div className="text-xs uppercase tracking-wide text-violet-400 font-semibold">
                    {acc.label || "Akun Premium"}
                  </div>
                  <div className="text-base font-medium break-all mt-0.5">{acc.email}</div>
                </div>

                {acc.note && (
                  <div className="text-xs text-zinc-400">{acc.note}</div>
                )}

                <div className="flex flex-wrap gap-2 pt-1">
                  <CopyButton value={acc.email} label="Salin Email" />
                  <a
                    href={acc.tempEmailLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs bg-violet-600 hover:bg-violet-500 transition rounded-md px-3 py-1 font-medium"
                  >
                    Buka Email Temp
                  </a>
                </div>
              </article>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
