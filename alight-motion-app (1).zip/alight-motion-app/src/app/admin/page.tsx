"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  collection,
  addDoc,
  deleteDoc,
  doc,
  updateDoc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { getRole } from "@/lib/auth";
import Header from "@/components/Header";
import CopyButton from "@/components/CopyButton";

type Account = {
  id: string;
  label?: string;
  email: string;
  password?: string;
  tempEmailLink: string;
  note?: string;
};

const empty = { label: "", email: "", password: "", tempEmailLink: "", note: "" };

export default function AdminPage() {
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [form, setForm] = useState({ ...empty });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const role = getRole();
    if (role !== "admin") {
      router.replace("/");
      return;
    }
    setReady(true);
  }, [router]);

  useEffect(() => {
    if (!ready) return;
    try {
      const q = query(collection(db, "accounts"), orderBy("createdAt", "desc"));
      const unsub = onSnapshot(
        q,
        (snap) => {
          setAccounts(
            snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Account, "id">) })),
          );
        },
        (err) => setError(err.message),
      );
      return () => unsub();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }, [ready]);

  function resetForm() {
    setForm({ ...empty });
    setEditingId(null);
    setError("");
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!form.email.trim() || !form.tempEmailLink.trim()) {
      setError("Email akun dan link email temp wajib diisi.");
      return;
    }
    setSaving(true);
    try {
      if (editingId) {
        await updateDoc(doc(db, "accounts", editingId), {
          label: form.label.trim(),
          email: form.email.trim(),
          password: form.password.trim(),
          tempEmailLink: form.tempEmailLink.trim(),
          note: form.note.trim(),
          updatedAt: serverTimestamp(),
        });
      } else {
        await addDoc(collection(db, "accounts"), {
          label: form.label.trim(),
          email: form.email.trim(),
          password: form.password.trim(),
          tempEmailLink: form.tempEmailLink.trim(),
          note: form.note.trim(),
          createdAt: serverTimestamp(),
        });
      }
      resetForm();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setSaving(false);
    }
  }

  function handleEdit(acc: Account) {
    setEditingId(acc.id);
    setForm({
      label: acc.label || "",
      email: acc.email || "",
      password: acc.password || "",
      tempEmailLink: acc.tempEmailLink || "",
      note: acc.note || "",
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function handleDelete(id: string) {
    if (!confirm("Yakin hapus akun ini?")) return;
    try {
      await deleteDoc(doc(db, "accounts", id));
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }

  if (!ready) return null;

  return (
    <div className="min-h-screen">
      <Header role="admin" />

      <main className="max-w-5xl mx-auto px-4 py-6 space-y-8">
        <section className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5">
          <h2 className="text-lg font-semibold mb-4">
            {editingId ? "Edit Akun" : "Tambah Akun Baru"}
          </h2>

          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-zinc-300 mb-1">Label (opsional)</label>
              <input
                value={form.label}
                onChange={(e) => setForm({ ...form, label: e.target.value })}
                placeholder="Contoh: Akun #1"
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 outline-none focus:border-violet-500"
              />
            </div>
            <div>
              <label className="block text-sm text-zinc-300 mb-1">Email Akun *</label>
              <input
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="email@domain.com"
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 outline-none focus:border-violet-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm text-zinc-300 mb-1">Password (opsional)</label>
              <input
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                placeholder="Password akun"
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 outline-none focus:border-violet-500"
              />
            </div>
            <div>
              <label className="block text-sm text-zinc-300 mb-1">Link Akses Email Temp *</label>
              <input
                value={form.tempEmailLink}
                onChange={(e) => setForm({ ...form, tempEmailLink: e.target.value })}
                placeholder="https://..."
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 outline-none focus:border-violet-500"
                required
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm text-zinc-300 mb-1">Catatan (opsional)</label>
              <textarea
                value={form.note}
                onChange={(e) => setForm({ ...form, note: e.target.value })}
                rows={2}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 outline-none focus:border-violet-500"
              />
            </div>

            {error && (
              <div className="md:col-span-2 text-sm text-red-400 bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2">
                {error}
              </div>
            )}

            <div className="md:col-span-2 flex gap-3">
              <button
                type="submit"
                disabled={saving}
                className="bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:opacity-90 transition rounded-lg py-2 px-5 font-medium disabled:opacity-60"
              >
                {saving ? "Menyimpan..." : editingId ? "Update Akun" : "Tambah Akun"}
              </button>
              {editingId && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="bg-zinc-800 hover:bg-zinc-700 transition rounded-lg py-2 px-5"
                >
                  Batal
                </button>
              )}
            </div>
          </form>
        </section>

        <section>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold">Daftar Akun ({accounts.length})</h2>
          </div>

          {accounts.length === 0 ? (
            <div className="bg-zinc-900/40 border border-dashed border-zinc-800 rounded-2xl p-8 text-center text-zinc-400">
              Belum ada akun tersimpan.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {accounts.map((acc) => (
                <article
                  key={acc.id}
                  className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 flex flex-col gap-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="text-xs uppercase tracking-wide text-violet-400 font-semibold">
                        {acc.label || "Akun Premium"}
                      </div>
                      <div className="text-base font-medium break-all">{acc.email}</div>
                    </div>
                    <div className="flex gap-2 shrink-0">
                      <button
                        onClick={() => handleEdit(acc)}
                        className="text-xs bg-zinc-800 hover:bg-zinc-700 rounded-md px-2.5 py-1"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(acc.id)}
                        className="text-xs bg-red-600/80 hover:bg-red-600 rounded-md px-2.5 py-1"
                      >
                        Hapus
                      </button>
                    </div>
                  </div>

                  {acc.password && (
                    <div className="text-sm text-zinc-300">
                      <span className="text-zinc-500">Password: </span>
                      <span className="font-mono">{acc.password}</span>
                    </div>
                  )}

                  <div className="text-sm break-all">
                    <span className="text-zinc-500">Email Temp: </span>
                    <a
                      href={acc.tempEmailLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-violet-400 hover:underline"
                    >
                      {acc.tempEmailLink}
                    </a>
                  </div>

                  {acc.note && (
                    <div className="text-xs text-zinc-400 border-t border-zinc-800 pt-2">
                      {acc.note}
                    </div>
                  )}

                  <div className="flex gap-2 pt-1">
                    <CopyButton value={acc.email} label="Salin Email" />
                    {acc.password && <CopyButton value={acc.password} label="Salin Password" />}
                    <CopyButton value={acc.tempEmailLink} label="Salin Link" />
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
