import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Alight Motion Premium Vault",
  description: "Penyimpanan akun Alight Motion Premium",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
