"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { getRole, setRole, tryLogin } from "@/lib/auth";

export default function LoginPage() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const role = getRole();
    if (role === "admin") router.replace("/admin");
    else if (role === "user") router.replace("/user");
  }, [router]);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    const role = tryLogin(password);
    if (!role) {
      setError("Password salah");
      setLoading(false);
      return;
    }
    setRole(role);
    router.push(role === "admin" ? "/admin" : "/user");
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-md bg-zinc-900/70 border border-zinc-800 rounded-2xl p-8 shadow-2xl backdrop-blur">
        <div className="mb-6 text-center">
          <div className="mx-auto h-12 w-12 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 grid place-items-center text-xl font-bold mb-3">
            AM
          </div>
          <h1 className="text-2xl font-bold">Alight Motion Premium</h1>
          <p className="text-sm text-zinc-400 mt-1">Vault Akun — silakan login</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm text-zinc-300 mb-1">Password</label>
            <input
              type="password"
              autoFocus
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 outline-none focus:border-violet-500"
              placeholder="Masukkan password admin / user"
              required
            />
          </div>

          {error && (
            <div className="text-sm text-red-400 bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:opacity-90 transition rounded-lg py-2.5 font-medium disabled:opacity-60"
          >
            {loading ? "Memproses..." : "Masuk"}
          </button>
        </form>

        <p className="mt-5 text-xs text-zinc-500 text-center">
          Password ditentukan di environment variable. Lihat README.
        </p>
      </div>
    </main>
  );
}
