# Alight Motion Premium Vault

Web aplikasi sederhana untuk menyimpan dan membagikan akun Alight Motion Premium dengan dua peran login:

- **Admin** — bisa menambah, mengedit, dan menghapus akun (email + link email temp + password).
- **User** — bisa melihat daftar akun, menyalin email akun, dan membuka link email temp.

Stack: **Next.js 14 (App Router) + TypeScript + Tailwind CSS + Firebase Firestore**. Siap di-deploy ke **Vercel**.

---

## 1. Setup Firebase

1. Buka [Firebase Console](https://console.firebase.google.com/) dan buat project baru.
2. Di menu **Build > Firestore Database**, klik **Create database** (mode test atau production, terserah).
3. Di menu **Project settings (ikon gerigi) > General > Your apps**, tambahkan **Web app** baru. Salin objek konfigurasi (`apiKey`, `authDomain`, `projectId`, dll).
4. (Opsional, untuk mode production) Buka **Firestore Rules** dan ganti aturan agar hanya membatasi sesuai kebutuhan. Contoh aturan paling sederhana untuk testing:

   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /{document=**} {
         allow read, write: if true;
       }
     }
   }
   ```

   > Catatan: aturan di atas membuka akses publik. Karena aplikasi ini dilindungi password di sisi client, ini cukup untuk pemakaian pribadi. Untuk keamanan lebih ketat, gunakan Firebase Auth.

---

## 2. Konfigurasi Environment

Salin `.env.local.example` menjadi `.env.local`, lalu isi sesuai konfigurasi Firebase kamu:

```bash
cp .env.local.example .env.local
```

Isi nilai-nilai berikut:

```
NEXT_PUBLIC_FIREBASE_API_KEY=...
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=...
NEXT_PUBLIC_FIREBASE_PROJECT_ID=...
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=...
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=...
NEXT_PUBLIC_FIREBASE_APP_ID=...

NEXT_PUBLIC_ADMIN_PASSWORD=ganti_password_admin
NEXT_PUBLIC_USER_PASSWORD=ganti_password_user
```

---

## 3. Jalankan Lokal

```bash
npm install
npm run dev
```

Buka [http://localhost:3000](http://localhost:3000) dan login dengan password admin atau user.

---

## 4. Deploy ke Vercel

1. Buat repo Git (GitHub/GitLab) dan push folder ini.
2. Buka [vercel.com](https://vercel.com), klik **Add New Project**, pilih repo kamu.
3. Vercel otomatis mendeteksi Next.js — biarkan default.
4. Di tab **Environment Variables**, tambahkan **semua variabel dari `.env.local`** (jangan upload `.env.local`).
5. Klik **Deploy**. Selesai!

> Alternatif tanpa Git: install Vercel CLI (`npm i -g vercel`), jalankan `vercel` di folder ini.

---

## 5. Struktur Data

Koleksi Firestore: `accounts`

Dokumen:

```
{
  label: string,           // opsional, contoh "Akun #1"
  email: string,           // email akun Alight Motion
  password: string,        // opsional, password akun
  tempEmailLink: string,   // link akses email temp untuk OTP
  note: string,            // opsional, catatan
  createdAt: timestamp,
  updatedAt: timestamp     // hanya jika di-edit
}
```

---

## 6. Cara Pakai

- Login dengan **password admin** untuk mengelola akun (tambah/edit/hapus).
- Login dengan **password user** untuk melihat dan menyalin akun.
- Tombol **Salin Email** menyalin email akun ke clipboard.
- Tombol **Buka Email Temp** membuka link email temp di tab baru.

Selamat memakai!
